import Link from "next/link";
import { createSupabaseServerClient } from "@/lib/supabase-server";
import { tambahProyekAction } from "@/actions/proyek-actions";

export default async function ManajemenProyekPage({
  searchParams,
}: {
  searchParams: Promise<{
    error?: string;
    success?: string;
  }>;
}) {
  const params = await searchParams;

  const supabase = await createSupabaseServerClient();

  const { data: daftarProyek } = await supabase
    .from("proyek")
    .select("*")
    .order("id", { ascending: true });

  return (
    <div className="space-y-8">
      {/* ================= HEADER ================= */}
      <div className="adm-up" style={{ ["--i" as string]: 0 }}>
        <h1 className="bg-gradient-to-r from-white via-[#d6dcff] to-[#7dd3fc] bg-clip-text text-2xl font-black tracking-tight text-transparent sm:text-3xl">
          Manajemen Proyek
        </h1>

        <p className="mt-2 max-w-2xl text-sm font-medium leading-6 text-slate-400">
          Tambah, ubah, atau hapus data proyek yang tampil di halaman
          portfolio.
        </p>
      </div>

      {/* ================= PESAN ERROR ================= */}
      {params.error && (
        <div
          className="adm-up rounded-xl border border-rose-400/30 bg-rose-500/10 p-4 text-sm font-bold text-rose-300 shadow-[0_0_24px_-8px_rgba(251,113,133,0.5)]"
          style={{ ["--i" as string]: 1 }}
        >
          {params.error}
        </div>
      )}

      {/* ================= PESAN SUCCESS ================= */}
      {params.success && (
        <div
          className="adm-up rounded-xl border border-[#7dd3fc]/30 bg-[#7dd3fc]/10 p-4 text-sm font-bold text-[#7dd3fc] shadow-[0_0_24px_-8px_rgba(125,211,252,0.5)]"
          style={{ ["--i" as string]: 1 }}
        >
          {params.success}
        </div>
      )}

      {/* ================= TABEL DAFTAR PROYEK ================= */}
      <div
        className="adm-up overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-xl shadow-[inset_0_1px_0_rgba(255,255,255,0.06),_0_18px_50px_rgba(2,4,16,0.4)]"
        style={{ ["--i" as string]: 2 }}
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="border-b border-white/10 bg-white/[0.02]">
              <tr>
                <th className="whitespace-nowrap px-4 py-3 text-left text-[11px] font-black uppercase tracking-widest text-slate-400">
                  Judul
                </th>
                <th className="whitespace-nowrap px-4 py-3 text-left text-[11px] font-black uppercase tracking-widest text-slate-400">
                  Kategori
                </th>
                <th className="whitespace-nowrap px-4 py-3 text-left text-[11px] font-black uppercase tracking-widest text-slate-400">
                  Featured
                </th>
                <th className="whitespace-nowrap px-4 py-3 text-left text-[11px] font-black uppercase tracking-widest text-slate-400">
                  Aksi
                </th>
              </tr>
            </thead>

            <tbody className="divide-y divide-white/5">
              {daftarProyek?.map((proyek, index) => (
                <tr
                  key={proyek.id}
                  className="group relative transition-all duration-300 hover:bg-[#8d7cff]/5"
                >
                  {/* JUDUL */}
                  <td className="px-4 py-3.5 font-bold text-white transition-colors group-hover:text-[#d6dcff]">
                    {proyek.judul}
                  </td>

                  {/* KATEGORI */}
                  <td className="whitespace-nowrap px-4 py-3.5 text-slate-400">
                    {proyek.kategori || "—"}
                  </td>

                  {/* FEATURED */}
                  <td className="px-4 py-3.5">
                    {proyek.featured ? (
                      <span className="inline-flex items-center gap-1.5 rounded-full border border-[#7dd3fc]/30 bg-[#7dd3fc]/10 px-2.5 py-1 text-xs font-black text-[#7dd3fc] shadow-[0_0_18px_-6px_rgba(125,211,252,0.6)]">
                        <span className="h-1.5 w-1.5 rounded-full bg-[#7dd3fc] shadow-[0_0_8px_#7dd3fc]" />
                        Featured
                      </span>
                    ) : (
                      <span className="text-slate-600">—</span>
                    )}
                  </td>

                  {/* AKSI */}
                  <td className="px-4 py-3.5">
                    <div className="flex gap-2">
                      <Link
                        href={`/admin/proyek/edit/${proyek.id}`}
                        className="group/edit relative inline-flex items-center gap-1.5 overflow-hidden whitespace-nowrap rounded-lg border border-[#8d7cff]/30 bg-[#8d7cff]/10 px-3 py-1.5 text-xs font-black text-[#c8bfff] transition-all duration-300 hover:border-[#7dd3fc]/50 hover:bg-[#7dd3fc]/15 hover:text-[#7dd3fc] hover:shadow-[0_0_20px_-4px_rgba(125,211,252,0.6)]"
                      >
                        <span className="absolute inset-0 -translate-x-[130%] bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover/edit:translate-x-[130%]" />
                        <span className="relative">✎</span>
                        <span className="relative">Edit</span>
                      </Link>

                      <Link
                        href={`/admin/proyek/hapus/${proyek.id}`}
                        className="group/del relative inline-flex items-center gap-1.5 overflow-hidden whitespace-nowrap rounded-lg border border-rose-400/30 bg-rose-500/10 px-3 py-1.5 text-xs font-black text-rose-300 transition-all duration-300 hover:border-rose-400/60 hover:bg-rose-500/20 hover:text-rose-200 hover:shadow-[0_0_20px_-4px_rgba(251,113,133,0.6)]"
                      >
                        <span className="absolute inset-0 -translate-x-[130%] bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-700 group-hover/del:translate-x-[130%]" />
                        <span className="relative">🗑</span>
                        <span className="relative">Hapus</span>
                      </Link>
                    </div>
                  </td>
                </tr>
              ))}

              {/* DATA KOSONG */}
              {(!daftarProyek || daftarProyek.length === 0) && (
                <tr>
                  <td colSpan={4} className="px-4 py-14 text-center">
                    <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.03] text-xl text-slate-500">
                      ◆
                    </div>
                    <p className="text-sm font-bold text-slate-300">
                      Belum ada data proyek
                    </p>
                    <p className="mt-1 text-xs font-medium text-slate-500">
                      Tambahkan proyek pertama kamu di bawah.
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ================= FORM TAMBAH PROYEK ================= */}
      <div
        className="adm-up relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-6 backdrop-blur-xl shadow-[inset_0_1px_0_rgba(255,255,255,0.06),_0_18px_50px_rgba(2,4,16,0.4)] sm:p-8"
        style={{ ["--i" as string]: 3 }}
      >
        {/* Glow di kanan atas */}
        <div
          aria-hidden
          className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-[radial-gradient(circle,_rgba(141,124,255,0.25),_transparent_70%)] blur-2xl"
        />

        <div className="relative">
          <div className="mb-6 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-[#8d7cff]/30 bg-[#8d7cff]/10 text-lg font-black text-[#b8a8ff] shadow-[0_0_22px_-6px_rgba(141,124,255,0.7)]">
              +
            </div>
            <div>
              <h2 className="text-lg font-black text-white">
                Tambah Proyek Baru
              </h2>
              <p className="text-xs font-medium text-slate-400">
                Isi data di bawah, lalu klik simpan.
              </p>
            </div>
          </div>

          <form action={tambahProyekAction} className="space-y-5">
            {/* JUDUL + KATEGORI */}
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-black uppercase tracking-widest text-slate-400">
                  Judul Proyek
                </label>
                <input
                  name="judul"
                  type="text"
                  required
                  placeholder="Contoh: Website Portfolio"
                  className="h-11 w-full rounded-lg border border-white/10 bg-white/[0.02] px-3 text-sm font-medium text-white placeholder:text-slate-500 outline-none transition focus:border-[#7dd3fc]/60 focus:bg-white/[0.04] focus:ring-4 focus:ring-[#7dd3fc]/10 focus:shadow-[0_0_28px_-6px_rgba(125,211,252,0.5)]"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-black uppercase tracking-widest text-slate-400">
                  Kategori
                </label>
                <input
                  name="kategori"
                  type="text"
                  placeholder="Web Application / Management System / IoT"
                  className="h-11 w-full rounded-lg border border-white/10 bg-white/[0.02] px-3 text-sm font-medium text-white placeholder:text-slate-500 outline-none transition focus:border-[#7dd3fc]/60 focus:bg-white/[0.04] focus:ring-4 focus:ring-[#7dd3fc]/10 focus:shadow-[0_0_28px_-6px_rgba(125,211,252,0.5)]"
                />
              </div>
            </div>

            {/* DESKRIPSI */}
            <div>
              <label className="mb-1.5 block text-xs font-black uppercase tracking-widest text-slate-400">
                Deskripsi
              </label>
              <textarea
                name="deskripsi"
                rows={3}
                placeholder="Tuliskan deskripsi singkat proyek..."
                className="w-full rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2.5 text-sm font-medium text-white placeholder:text-slate-500 outline-none transition focus:border-[#7dd3fc]/60 focus:bg-white/[0.04] focus:ring-4 focus:ring-[#7dd3fc]/10 focus:shadow-[0_0_28px_-6px_rgba(125,211,252,0.5)]"
              />
            </div>

            {/* TEKNOLOGI + LINK */}
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-xs font-black uppercase tracking-widest text-slate-400">
                  Teknologi
                </label>
                <input
                  name="teknologi"
                  type="text"
                  placeholder="Next.js, Tailwind, Supabase"
                  className="h-11 w-full rounded-lg border border-white/10 bg-white/[0.02] px-3 text-sm font-medium text-white placeholder:text-slate-500 outline-none transition focus:border-[#7dd3fc]/60 focus:bg-white/[0.04] focus:ring-4 focus:ring-[#7dd3fc]/10 focus:shadow-[0_0_28px_-6px_rgba(125,211,252,0.5)]"
                />
                <p className="mt-1.5 text-xs font-medium text-slate-500">
                  Pisahkan teknologi menggunakan koma.
                </p>
              </div>

              <div>
                <label className="mb-1.5 block text-xs font-black uppercase tracking-widest text-slate-400">
                  Link Proyek
                </label>
                <input
                  name="link"
                  type="url"
                  placeholder="https://..."
                  className="h-11 w-full rounded-lg border border-white/10 bg-white/[0.02] px-3 text-sm font-medium text-white placeholder:text-slate-500 outline-none transition focus:border-[#7dd3fc]/60 focus:bg-white/[0.04] focus:ring-4 focus:ring-[#7dd3fc]/10 focus:shadow-[0_0_28px_-6px_rgba(125,211,252,0.5)]"
                />
              </div>
            </div>

            {/* GAMBAR */}
            <div>
              <label className="mb-1.5 block text-xs font-black uppercase tracking-widest text-slate-400">
                Gambar Proyek
              </label>
              <input
                name="gambar"
                type="file"
                accept="image/png,image/jpeg,image/webp"
                required
                className="w-full cursor-pointer rounded-lg border border-white/10 bg-white/[0.02] px-3 py-2 text-sm font-medium text-slate-300 outline-none transition file:mr-4 file:cursor-pointer file:rounded-lg file:border-0 file:bg-gradient-to-br file:from-[#8d7cff] file:to-[#7dd3fc] file:px-4 file:py-2 file:text-sm file:font-black file:text-[#04102a] hover:file:shadow-[0_0_24px_-6px_rgba(141,124,255,0.8)] focus:border-[#7dd3fc]/60 focus:ring-4 focus:ring-[#7dd3fc]/10"
              />
              <p className="mt-1.5 text-xs font-medium text-slate-500">
                Format JPG, PNG, atau WEBP. Maksimal 5 MB.
              </p>
            </div>

            {/* FEATURED */}
            <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-white/10 bg-white/[0.02] px-4 py-3 transition hover:border-[#7dd3fc]/40 hover:bg-white/[0.04]">
              <input
                type="checkbox"
                name="featured"
                className="h-4 w-4 cursor-pointer rounded border-white/20 bg-white/[0.05] text-[#7dd3fc] accent-[#7dd3fc]"
              />
              <span className="text-sm font-bold text-slate-300">
                Tandai sebagai <span className="text-[#7dd3fc]">Featured</span>
              </span>
            </label>

            {/* BUTTON */}
            <div className="flex justify-end pt-2">
              <button
                type="submit"
                className="group relative inline-flex h-11 items-center justify-center gap-2 overflow-hidden rounded-xl bg-gradient-to-br from-[#8d7cff] to-[#7dd3fc] px-6 text-sm font-black text-[#04102a] shadow-[0_14px_40px_-10px_rgba(91,140,255,0.65),_inset_0_1px_0_rgba(255,255,255,0.4)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_22px_54px_-10px_rgba(125,211,252,0.7),_inset_0_1px_0_rgba(255,255,255,0.5)] active:scale-[0.98]"
              >
                <span className="absolute inset-0 -translate-x-[130%] bg-gradient-to-r from-transparent via-white/50 to-transparent transition-transform duration-700 group-hover:translate-x-[130%]" />
                <span className="relative">💾</span>
                <span className="relative">Simpan Proyek</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}