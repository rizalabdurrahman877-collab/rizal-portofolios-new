﻿import { createSupabaseServerClient } from "@/lib/supabase-server";
import AdminShell from "@/components/admin/AdminShell";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = await createSupabaseServerClient();
  const siteUrl = (
    process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"
  ).trim();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  // =========================
  // BELUM LOGIN → tampilkan halaman login dengan
  // background gelap yang senada dengan portfolio.
  // =========================
  if (!user) {
    return (
      <div className="relative min-h-screen bg-[#050816] text-slate-100">
        {/* Background glow global (senada portfolio) */}
        <div
          aria-hidden
          className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
        >
          <div className="absolute -top-40 -left-40 h-[40rem] w-[40rem] rounded-full bg-[radial-gradient(circle,_rgba(141,124,255,0.22),_transparent_70%)] blur-3xl" />
          <div className="absolute -bottom-56 -right-40 h-[44rem] w-[44rem] rounded-full bg-[radial-gradient(circle,_rgba(125,211,252,0.18),_transparent_70%)] blur-3xl" />

          {/* tekstur titik halus */}
          <div
            className="absolute inset-0 opacity-[0.05]"
            style={{
              backgroundImage:
                "radial-gradient(rgba(255,255,255,0.7) 0.6px, transparent 0.6px)",
              backgroundSize: "5px 5px",
            }}
          />
        </div>

        {/* Konten login di tengah layar */}
        <main className="flex min-h-screen items-center justify-center px-4 py-10">
          <div className="w-full max-w-md">{children}</div>
        </main>
      </div>
    );
  }

  // =========================
  // SUDAH LOGIN → render AdminShell (sidebar + topbar + konten)
  // =========================
  return (
    <AdminShell email={user.email ?? null} siteUrl={siteUrl}>
      {children}
    </AdminShell>
  );
}